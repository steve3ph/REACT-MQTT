
// app.js
var express = require('express');
const cors = require('cors');
var app = express();
var server = require('http').createServer(app);
var io = require('socket.io')(server, {
 cors: {
    origin: "http://localhost:3001",
    methods: ["GET", "POST"]
 }
});

app.use(cors());

// Import the pg module to interact with your PostgreSQL database
const { Pool } = require('pg');
const pool = new Pool({
 user: 'postgres',
 host: 'localhost',
 database: 'iot_db',
 password: 'steby@seban8855',
 port: 5432,
});

// Fetch real-time sensor data
app.get('/real-time-data', async (req, res) => {
 try {
    const result = await pool.query('SELECT * FROM sensor_data ORDER BY timestamp DESC LIMIT 10');
    res.json(result.rows);
 } catch (err) {
    console.error('Failed to fetch data:', err);
    res.status(500).json({ error: 'Failed to fetch data' });
 }
});

// Fetch historical sensor data
app.get('/historical-data', async (req, res) => {
    try {
        const { device_number, startDate, endDate } = req.query;
        console.log('Parameters:', device_number, startDate, endDate); // Log the parameters

        if (!device_number) {
            return res.status(400).json({ error: 'device_number parameter is required' });
        }

        const result = await pool.query('SELECT * FROM sensor_data WHERE device_number = $1 AND timestamp BETWEEN $2::timestamp AND $3::timestamp ORDER BY timestamp ASC LIMIT 10', [device_number, startDate, endDate]);

        console.log('Query result:', result.rows); // Log the query result

        res.json(result.rows);
    } catch (err) {
        console.error('Failed to fetch data:', err);
        res.status(500).json({ error: 'Failed to fetch data', details: err.message });
    }
})

app.get('/', function (req, res) {
 res.send('Hello World!');
});

// Emit 'real-time-data' event every second
setInterval(async () => {
 const result = await pool.query('SELECT * FROM sensor_data ORDER BY timestamp DESC LIMIT 10');
 io.emit('real-time-data', result.rows);
}, 5000);

server.listen(3000, function () {
 console.log('Example app listening on port 3000!');
});




const mqtt = require('mqtt');
const client = mqtt.connect('mqtt://localhost:1883');

function simulateDevice(deviceNumber) {
 client.on('connect', function () {
    console.log(`Connected to MQTT broker for device ${deviceNumber}`);

    // Generate random temperature and humidity values
    function generateValues() {
      const temperature = Math.floor(Math.random() * 101);
      const humidity = Math.floor(Math.random() * 101);

      return { temperature, humidity };
    }

    // Publish values every 5 seconds
    setInterval(() => {
      const values = generateValues();
      const topicTemperature = `device${deviceNumber}/temperature`;
      const topicHumidity = `device${deviceNumber}/humidity`;

      client.publish(topicTemperature, values.temperature.toString());
      client.publish(topicHumidity, values.humidity.toString());

      console.log(`Device ${deviceNumber}: Temperature - ${values.temperature}, Humidity - ${values.humidity}`);
    }, 5000);
 });
}

for (let i = 1; i <= 10; i++) {
 simulateDevice(i);
}

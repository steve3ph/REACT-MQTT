const mqtt = require('mqtt');
const client = mqtt.connect('mqtt://localhost:1883');
const { Pool } = require('pg');
const pool = new Pool({
 user: 'postgres',
 host: 'localhost',
 database: 'iot_db',
 password: 'steby@seban8855',
 port: 5432,
});

client.on('connect', function () {
 console.log('Connected to MQTT broker');

 // Subscribe to all device topics
 for (let i = 1; i <= 10; i++) {
    client.subscribe(`device${i}/temperature`);
    client.subscribe(`device${i}/humidity`);
 }
});


client.on('message', function (topic, message) {
    // Process the message and save it to the database
    const [deviceNumber, parameter] = topic.split('/');
    const value = parseInt(message);
    const timestamp = new Date();
   
    pool.query('INSERT INTO sensor_data (device_number, parameter, value, timestamp) VALUES ($1, $2, $3, $4)', [deviceNumber, parameter, value, timestamp])
      .then(() => console.log('Data saved successfully'))
      .catch((err) => console.error('Failed to save data:', err));
});
